package net.masterthought.cucumber.json;

public class Row {

    // Start: attributes from JSON file report
    private final String[] cells = new String[0];
    // End: attributes from JSON file report

    public String[] getCells() {
        return cells;
    }
}
